var url = "https://boothjeniuscom.000webhostapp.com/";

$(document).on('pageshow','#getallmarker', function(event) {
	markerarrmap();
});

function markerarrmap() {
	if (navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(onSuccess, onError, {timeout:7000, enableHighAccuracy: true});
	}else{
        error('not supported');
    }
}

function onSuccess(position) {
	var posisiku = new google.maps.LatLng(position.coords.latitude,position.coords.longitude);
		
	var myOptions = {
		zoom: 12,
		center: posisiku,
		mapTypeId: google.maps.MapTypeId.ROADMAP
		};
		
	var map = new google.maps.Map(document.getElementById("map_canvas"),myOptions);
			
	var marker = new google.maps.Marker({
        position: posisiku,
        map: map,
		animation: google.maps.Animation.DROP,
        icon: 'gambar/ping.png'
        });
		
	var markers = [];
    var user_radius = 50000;

	$.getJSON(url + 'pilihrs.php', function (data) {
		var listrs = data.items;
        $.each(listrs, function (index, loaddata) {

            var rmsakit = new google.maps.LatLng(loaddata.latitude, loaddata.longitude);
            var markerall = new google.maps.Marker({
                position: rmsakit,
				icon: 'gambar/jenius.png'
            });
            markers.push(markerall);
			
			
				if (typeof(Number.prototype.toRad) === "undefined") {
				  Number.prototype.toRad = function() {
					return this * Math.PI / 180;
				  }
				}
				
				var lat1 = position.coords.latitude; 
				var lon1 = position.coords.longitude;
				var lat2 = parseFloat(loaddata.latitude);
				var lon2 = parseFloat(loaddata.longitude); 
				
				var R = 6371; // metres
					var dlat1 = lat1.toRad();
					var dlat2 = lat2.toRad();
					var slat = (lat2-lat1).toRad();
					var slon = (lon2-lon1).toRad();

					var a = Math.sin(slat/2) * Math.sin(slat/2) +
							Math.cos(dlat1) * Math.cos(dlat2) *
							Math.sin(slon/2) * Math.sin(slon/2);
					var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

					var d = R * c;
			
			
			var info_window = new google.maps.InfoWindow();
			google.maps.event.addListener(markerall, 'click', (function(markerall) {
                return function() {
                    info_window.setContent(loaddata.nama_rs+'</br> Jarak '+d+' km');
                    info_window.open(map, markerall);
                }
            })(markerall));
        });
        
    var circle = new google.maps.Circle({
		map: map,
		clickable: false,
		// metres
		radius: user_radius,
		//fillColor: '#c0e4dd',
		fillOpacity: 0,
		//strokeColor: '#313131',
		//strokeOpacity: .4,
		strokeWeight: 0
	});
	
	
	circle.bindTo('center', marker, 'position');
	
	var bounds = circle.getBounds();
	for (var i = 0; i < markers.length; i++) {
		if (bounds.contains(markers[i].getPosition())) {
			markers[i].setMap(map);
		} else {
			markers[i].setMap(null);
		}
	}
    });
}

function onError() {
	alert('Aktifkan GPS Anda !!!');
    window.location.href = 'index.html';
}