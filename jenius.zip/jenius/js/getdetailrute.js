var url = "https://boothjeniuscom.000webhostapp.com/";
var id = getUrlVars()["id"];

$('#pagedetail').live('pageshow', function(event) {
	getdetailrs();
});


$('#directmap').live('pageshow', function(event) {
	getdirection();
});

$('#directmapinfo').live('pageshow', function(event) {
	getdirection();
});
/*$(document).ajaxError(function(event, request, settings) {
	alert('Periksa Koneksi Anda');
    window.location.href = 'index.html';
});*/

function getdetailrs() {
	$.getJSON(url + 'ambildetailrs.php?id='+id, function(data) {
		loaddetailrs = data.items;
		console.log(loaddetailrs);
			$('#gambarRS').attr('src', 'https://boothjeniuscom.000webhostapp.com/gambar/' +loaddetailrs.gambar);
			$('#namaRS').text('Nama : '+loaddetailrs.nama_rs);
			$('#alamatRS').text('Alamat : '+loaddetailrs.alamat_rs);
			$('#teleponRS').text('Telepon : '+loaddetailrs.telepon_rs);
			$('#latRS').text('Latitude : '+loaddetailrs.latitude);
			$('#lngRS').text('Longitude : '+loaddetailrs.longitude);
		
	});	
}

function getdirection() {
 if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(onSuccess, onError, {timeout:7000, enableHighAccuracy: true});
      } else {
        error('not supported');
      }
}

var directionDisplay;
var directionsService;
var map;

function onSuccess(position) {
	$.getJSON(url + 'ambildetailrs.php?id='+id, function(data) {
	loaddata = data.items;
	console.log(loaddata);
	
	directionsDisplay = new google.maps.DirectionsRenderer();
	directionsService = new google.maps.DirectionsService();
        
	map = new google.maps.Map(document.getElementById('map_canvas'));
	directionsDisplay.setMap(map);
	directionsDisplay.setPanel(document.getElementById("directionPanel"));
	
	var tujuan = new google.maps.LatLng(loaddata.latitude, loaddata.longitude);
	var posisi = position.coords.latitude + ',' + position.coords.longitude;
	var request = {
		origin:posisi,
		destination:tujuan,
		travelMode: google.maps.DirectionsTravelMode.DRIVING
	};
        
	directionsService.route(request, function(response, status) {
		if (status == google.maps.DirectionsStatus.OK) {
			directionsDisplay.setDirections(response);
			}
		});
	});
}

function onError() {
	alert('Aktifkan GPS Anda !!!');
    window.location.href = 'index.html';
}

function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
		for(var i = 0; i < hashes.length; i++)
		{
			hash = hashes[i].split('=');
			vars.push(hash[0]);
			vars[hash[0]] = hash[1];
		}
    return vars;
}