var url = "https://boothjeniuscom.000webhostapp.com/";

var id = getUrlVars()["id"];

$('#pagelist').live('pageshow', function(event) {
	getlistrs();
});

$(document).ajaxError(function(event, request, settings) {
	alert('Periksa Koneksi Anda');
    window.location.href = 'index.html';
});

function getlistrs() {
	$.getJSON(url + 'pilihrs.php', function(data) {
		var listrs = data.items;
		$.each(listrs, function(index, loaddata) {
			$('#RsList').append('<li><a href="detailrute.html?id=' + loaddata.id + 'data-transition="flip" rel="external">' +
					'<h2>' + loaddata.nama_rs + '</h2>');
		});
		$('#RsList').listview('refresh');
	});
}

function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
		for(var i = 0; i < vars.length; i++)
		{
			hash = hashes[i].split('=');
			vars.push(hash[0]);
			vars[hash[0]] = hash[1];
		}
    return vars;
}