<?php
session_start();
$username = $_SESSION['username'];
$isLoggedIn = $_SESSION['isLoggedIn'];
 
if($isLoggedIn != '1'){
    session_destroy();
    header('Location: login.php');
}
?>
 
<p align="right"><a href="logout.php">Logout</a></p>

Selamat Datang <?php echo $username; ;?><br>
<?php
//membuat koneksi ke database
$host = 'localhost';
  $user = 'root';      
  $password = '';      
  $database = 'db_rumahsakit';  
    
  $konek_db = mysql_connect($host, $user, $password);    
  $find_db = mysql_select_db($database) ;
?>

<center> 
MENAMPILKAN DATA BOOTH
<br>
<br>

<!-- ///////////////////////////// Script untuk membuat tabel///////////////////////////////// -->

<table  border='1' Width='800'>  
	<thead>
		<tr>
			<th> Id </th>
			<th> Nama </th>
			<th> Alamat </th>
			<th> Telepon </th>
			<th> Latitude</th>
			<th> Longitude</th>
			<th> Gambar</th>
		</tr>
	</thead>	
	<tbody>
	<?php
		//buat koneksi dengan MySQL
		$link=mysql_connect('localhost','root','');
		 
		//gunakan database universitas
		$result=mysql_query('db_rumahsakit');
					   
		//tampilkan tabel mahasiswa_ilkom
		$result=mysql_query('SELECT * FROM tb_rumahsakit');
		while ($row=mysql_fetch_array($result, MYSQL_NUM))
		{
		   echo "<tr>";
				echo "<td>". "$row[0]" ."</td>";
				echo "<td>". "$row[1]" ."</td>";
				echo "<td>". "$row[2]" ."</td>";
				echo "<td>". "$row[3]" ."</td>";
				echo "<td>". "$row[4]" ."</td>";
				echo "<td>". "$row[5]" ."</td>";
				echo "<td>". "$row[6]" ."</td>";
				//echo "$row[0] $row[1] $row[2] $row[3] $row[4]";
		   echo "</tr>";
		   //echo "<br />";
		   
		}
	?>
	</tbody>
	
</table>
<button type="button">Add</button>
<button type="button">Edit</button>
<button type="button">Save</button>
<button type="button">Delete</button>
<?php
	// //buat koneksi dengan MySQL
	// $link=mysql_connect('localhost','root','');
	 
	// //gunakan database universitas
	// $result=mysql_query('db_rumahsakit');
				   
	// //tampilkan tabel mahasiswa_ilkom
	// $result=mysql_query('SELECT * FROM tb_rumahsakit');
	// while ($row=mysql_fetch_array($result, MYSQL_NUM))
	// {
	   // echo "$row[0] $row[1] $row[2] $row[3] $row[4]";
	   // echo "<br />";
	// }
?>
